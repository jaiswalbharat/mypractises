import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.io.File;

@SpringBootApplication
@EnableScheduling
public class LoadRequestApplication {

    private static final String LOCAL_TEMP_DIR = "/tmp/processing";

    public static void main(String[] args) {
        createTempDirectory();
        SpringApplication.run(LoadRequestApplication.class, args);
    }

    private static void createTempDirectory() {
        File tempDir = new File(LOCAL_TEMP_DIR);
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }
    }
}

