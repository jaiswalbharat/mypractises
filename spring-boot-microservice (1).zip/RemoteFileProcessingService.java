import com.jcraft.jsch.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Vector;

@Service
public class RemoteFileProcessingService {

    @Autowired
    private SshConfig sshConfig;

    @Autowired
    private ApiService apiService;

    @Autowired
    private FileService fileService;

    private static final String REMOTE_INPUT_DIR = "/remote/input";
    private static final String REMOTE_OUTPUT_DIR = "/remote/output";
    private static final String LOCAL_TEMP_DIR = "/tmp/processing";

    @Scheduled(fixedDelay = 60000) // Run every 60 seconds
    public void pollAndProcessFiles() {
        try {
            Vector<ChannelSftp.LsEntry> files = listRemoteFiles(REMOTE_INPUT_DIR);
            for (ChannelSftp.LsEntry entry : files) {
                if (!entry.getAttrs().isDir()) {
                    String filename = entry.getFilename();
                    processFile(filename);
                }
            }
        } catch (JSchException | SftpException | IOException e) {
            e.printStackTrace();
        }
    }

    private Vector<ChannelSftp.LsEntry> listRemoteFiles(String remoteDir) throws JSchException, SftpException {
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = createSession();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            return channelSftp.ls(remoteDir);
        } finally {
            if (channelSftp != null) {
                channelSftp.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }
        }
    }

    private void processFile(String filename) throws JSchException, SftpException, IOException {
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = createSession();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();

            // Download file
            String localFilePath = LOCAL_TEMP_DIR + "/" + filename;
            channelSftp.get(REMOTE_INPUT_DIR + "/" + filename, localFilePath);

            // Process file
            String processedContent = processFileContent(localFilePath);

            // Write processed content to a new file
            String processedFilename = "processed_" + filename;
            String processedFilePath = LOCAL_TEMP_DIR + "/" + processedFilename;
            fileService.writeResponseToFile(processedContent, processedFilePath);

            // Upload processed file
            channelSftp.put(processedFilePath, REMOTE_OUTPUT_DIR + "/" + processedFilename);

            // Delete original file from remote input directory
            channelSftp.rm(REMOTE_INPUT_DIR + "/" + filename);

            // Clean up local temporary files
            Files.deleteIfExists(Path.of(localFilePath));
            Files.deleteIfExists(Path.of(processedFilePath));

        } finally {
            if (channelSftp != null) {
                channelSftp.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }
        }
    }

    private String processFileContent(String filePath) throws IOException {
        StringBuilder processedContent = new StringBuilder();
        for (String line : fileService.readLinesFromFile(filePath)) {
            String processedLine = apiService.callApi("http://localhost:8081/api", line);
            processedContent.append(processedLine).append("\n");
        }
        return processedContent.toString();
    }

    private Session createSession() throws JSchException {
        JSch jsch = new JSch();
        Session session = jsch.getSession(sshConfig.getUsername(), sshConfig.getHost(), sshConfig.getPort());
        session.setPassword(sshConfig.getPassword());
        session.setConfig("StrictHostKeyChecking", "no");
        session.connect();
        return session;
    }
}

