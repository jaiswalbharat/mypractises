import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class FileService {

    public List<String> readLinesFromFile(String filePath) throws IOException {
        File file = new File(filePath);
        return FileUtils.readLines(file, StandardCharsets.UTF_8);
    }

    public void writeResponseToFile(String response, String filePath) throws IOException {
        File file = new File(filePath);
        FileUtils.writeStringToFile(file, response, StandardCharsets.UTF_8);
    }
}

