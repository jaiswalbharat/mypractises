import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class LoadRequestApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoadRequestApplication.java, args);
    }
}

