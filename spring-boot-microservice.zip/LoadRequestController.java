package com.example.loadrequest.controller;

import com.example.loadrequest.service.RemoteFileProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoadRequestController {

    private final RemoteFileProcessingService remoteFileProcessingService;

    @Autowired
    public LoadRequestController(RemoteFileProcessingService remoteFileProcessingService) {
        this.remoteFileProcessingService = remoteFileProcessingService;
    }

    @PostMapping("/trigger-processing")
    public String triggerProcessing() {
        remoteFileProcessingService.pollAndProcessFiles();
        return "Processing triggered";
    }
}

