import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoadRequestController {

    @Autowired
    private FileService fileService;

    @Autowired
    private ApiService apiService;

    @Autowired
    private SshService sshService;

    @PostMapping("/process")
    public String processRequests(@RequestParam String inputFilePath,
                                  @RequestParam String apiUrl,
                                  @RequestParam String outputFilePath,
                                  @RequestParam String remoteDirectory) {
        try {
            // Read requests from file
            List<String> requests = fileService.readLinesFromFile(inputFilePath);

            StringBuilder responseBuilder = new StringBuilder();

            // Process each request
            for (String request : requests) {
                String response = apiService.callApi(apiUrl, request);
                responseBuilder.append(response).append("\n");
            }

            // Write response to file
            fileService.writeResponseToFile(responseBuilder.toString(), outputFilePath);

            // Transfer file via SSH
            sshService.transferFile(outputFilePath, remoteDirectory + "/" + new File(outputFilePath).getName());

            return "Processing completed successfully";
        } catch (Exception e) {
            return "Error occurred: " + e.getMessage();
        }
    }
}

