package com.example.loadrequest.service;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import static com.example.loadrequest.LoadRequestApplication.LOCAL_TEMP_DIR;

@Service
public class RemoteFileProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(RemoteFileProcessingService.class);
    private static final String REMOTE_INPUT_DIR = "/remote/input";
    private static final String REMOTE_OUTPUT_DIR = "/remote/output";

    private final SshService sshService;
    private final ApiService apiService;
    private final FileService fileService;

    @Autowired
    public RemoteFileProcessingService(SshService sshService, ApiService apiService, FileService fileService) {
        this.sshService = sshService;
        this.apiService = apiService;
        this.fileService = fileService;
    }

    @Scheduled(fixedDelay = 60000) // Run every 60 seconds
    public void pollAndProcessFiles() {
        try {
            Vector<ChannelSftp.LsEntry> files = listRemoteFiles(REMOTE_INPUT_DIR);
            for (ChannelSftp.LsEntry entry : files) {
                if (!entry.getAttrs().isDir() && !entry.getFilename().equals(".") && !entry.getFilename().equals("..")) {
                    String filename = entry.getFilename();
                    processFile(filename);
                }
            }
        } catch (Exception e) {
            logger.error("Error in polling files", e);
        }
    }

    private Vector<ChannelSftp.LsEntry> listRemoteFiles(String remoteDir) throws JSchException, SftpException {
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = sshService.createSession();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            return channelSftp.ls(remoteDir);
        } finally {
            if (channelSftp != null) {
                channelSftp.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }
        }
    }

    private void processFile(String filename) {
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = sshService.createSession();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();

            // Download file
            String localFilePath = LOCAL_TEMP_DIR + File.separator + filename;
            channelSftp.get(REMOTE_INPUT_DIR + "/" + filename, localFilePath);

            // Process file
            String processedContent = processFileContent(localFilePath);

            // Write processed content to a new file
            String processedFilename = "processed_" + filename;
            String processedFilePath = LOCAL_TEMP_DIR + File.separator + processedFilename;
            fileService.writeResponseToFile(processedContent, processedFilePath);

            // Upload processed file
            channelSftp.put(processedFilePath, REMOTE_OUTPUT_DIR + "/" + processedFilename);

            // Delete original file from remote input directory
            channelSftp.rm(REMOTE_INPUT_DIR + "/" + filename);

            // Clean up local temporary files
            cleanupLocalFile(localFilePath);
            cleanupLocalFile(processedFilePath);

        } catch (Exception e) {
            logger.error("Error processing file: " + filename, e);
        } finally {
            if (channelSftp != null) {
                channelSftp.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }
        }
    }

    private void cleanupLocalFile(String filePath) {
        File file = new File(filePath);
        if (file.exists() && !file.delete()) {
            logger.warn("Failed to delete temporary file: {}", filePath);
        }
    }

    private String processFileContent(String filePath) throws IOException {
        StringBuilder processedContent = new StringBuilder();
        for (String line : fileService.readLinesFromFile(filePath)) {
            try {
                String processedLine = apiService.callApi("http://localhost:8081/api", line);
                processedContent.append(processedLine).append("\n");
            } catch (Exception e) {
                logger.error("Error processing line: " + line, e);
                processedContent.append("ERROR: ").append(e.getMessage()).append("\n");
            }
        }
        return processedContent.toString();
    }
}

