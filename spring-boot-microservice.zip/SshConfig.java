import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "ssh")
public class SshConfig {
    private String host;
    private int port;
    private String username;
    private String password;

    // Getters and setters
    // ...
}

