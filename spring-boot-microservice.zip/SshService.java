package com.example.loadrequest.service;

import com.example.loadrequest.config.SshConfig;
import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SshService {

    private static final Logger logger = LoggerFactory.getLogger(SshService.class);
    private final SshConfig sshConfig;

    @Autowired
    public SshService(SshConfig sshConfig) {
        this.sshConfig = sshConfig;
    }

    public Session createSession() throws JSchException {
        try {
            JSch jsch = new JSch();
            Session session = jsch.getSession(sshConfig.getUsername(), sshConfig.getHost(), sshConfig.getPort());
            session.setPassword(sshConfig.getPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect(30000); // 30 seconds timeout
            return session;
        } catch (JSchException e) {
            logger.error("Failed to create SSH session", e);
            throw e;
        }
    }
}

